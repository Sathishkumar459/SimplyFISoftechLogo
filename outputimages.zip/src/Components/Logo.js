import React from 'react';

import '../Styles/Design.css';

class Design extends React.Component{
    render(){
        return(
            <div>
                <div className="container">
                    
                   <div className="divName ">
                    
                   <div className="box1 ">
                   <div className="box2 ">
                   <div className="box3 ">
                   <div className="box4 ">
                   <div className="text">HTML<span>&</span>CSS<br></br>design and build website</div>
                    
                    </div>
                    </div></div>
                   </div>
                   </div> 
                   
                
                </div>       
            </div>
        )
    }
}
export default Design;