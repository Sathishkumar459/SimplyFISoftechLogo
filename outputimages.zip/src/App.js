
import './App.css';
import Design from './Components/Logo';

function App() {
  return (
    <div className="App">
     < Design />
    </div>
  );
}

export default App;
